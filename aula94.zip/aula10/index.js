// NaN - Not a number parseInt (inteiro), parseFloat(decimais)
const num1 = 10;
const num2 = Number('Luiz');
const num3 = Number('5.2');

/*console.log(num1 + num2);
console.log(typeof num2);*/

console.log(num1 + num3);
console.log(typeof num3);

let varA='A'
let varB='B'
let varC='C'

const a = varA
varA=varB 
varB=varC 
varC=a 

console.log(varA,varB,varC)
