// function saudacao(nome) {
//     return `bom dia ${nome}`
// }

// const var1 = saudacao('teste')
// console.log(var1)

// function soma(x, y) {
//     return x + y //escopo da função
// }

// console.log(soma(9, 8))

// const raiz = function (n) {
//     return n ** 0.5
// }

// console.log(raiz(81))
// console.log(raiz(1024))
// console.log(raiz(25))

const raiz2 = (n) => n ** 0.5

console.log(raiz2(9))
console.log(raiz2(144))
console.log(raiz2(256))

