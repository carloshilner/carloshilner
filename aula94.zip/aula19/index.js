/*
Primitivos (imutáveis) - string, number, boolean, undefined, 
null (bigint, symbol) - Valores copiados

Referência (mutável) - array, object, function - Passados por referência
*/
const a = {
  nome: 'Luiz',
  sobrenome: 'Otávio'
};
const b = a;

b.nome = 'João';
//console.log(a);
//console.log(b);

const a1 = {
  nome: 'Luiz',
  sobrenome: 'Otávio'
};
const b1 = {...a1};

b1.nome = 'João';
console.log(a1);
console.log(b1);

