document.addEventListener('DOMContentLoaded', () => {
    const form = document.querySelector('.form');
    const resultado = document.querySelector('.resultado');
    const pessoas = [];
  
    // Armazena as referências dos inputs
    const nomeInput = form.querySelector('.nome');
    const sobrenomeInput = form.querySelector('.sobrenome');
    const pesoInput = form.querySelector('.peso');
    const alturaInput = form.querySelector('.altura');
  
    form.addEventListener('submit', (evento) => {
      evento.preventDefault();
  
      const nome = nomeInput.value.trim();
      const sobrenome = sobrenomeInput.value.trim();
      const peso = pesoInput.value.trim();
      const altura = alturaInput.value.trim();
  
      // Validação simples para garantir que os campos não estejam vazios
      if (!nome || !sobrenome || !peso || !altura) {
        alert('Por favor, preencha todos os campos!');
        return;
      }
  
      pessoas.push({ nome, sobrenome, peso, altura });
      console.log(pessoas);
  
      // Cria um novo parágrafo e insere o resultado
      const p = document.createElement('p');
      p.textContent = `Nome: ${nome} ${sobrenome} - Peso: ${peso} - Altura: ${altura}`;
      resultado.appendChild(p);
  
      // Reseta o formulário para um novo registro
      form.reset();
    });
  });
  