/*
&& -> false && true -> false "o valor mesmo"
|| -> true && false -> vai retornar "o valor verdadeiro"
*/
console.log(0 || false || null || 'luiz' || true)

const a = 0
const b = null
const c = 'false' //true a string
const d = false
const e = NaN //ultima falsa retorna
console.log(a || b || c || d || e)