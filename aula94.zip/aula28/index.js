function zeroAEsquerda(num) {
  return num >= 10 ? num : `0${num}`;
}

function formataData(data) {
  const dia = zeroAEsquerda(data.getDate());
  const mes = zeroAEsquerda(data.getMonth() + 1);
  const ano = zeroAEsquerda(data.getFullYear());
  const hora = zeroAEsquerda(data.getHours());
  const min = zeroAEsquerda(data.getMinutes());
  const seg = zeroAEsquerda(data.getSeconds());
  return `${dia}/${mes}/${ano} ${hora}:${min}:${seg}`;
}
const tresHoras = 60 * 60 * 3 * 1000
const data0 = new Date(0 + tresHoras);
console.log(data0);

const data = new Date();
const dataBrasil = formataData(data);

console.log(dataBrasil);

const data1 = new Date(2019, 3, 20, 15, 14, 12, 1000);//3 = abril
const data2 = new Date('2024-04-20 20:34:45');//3 = abril
console.log(data1.toString())
console.log(data2.toString())

console.log(data);