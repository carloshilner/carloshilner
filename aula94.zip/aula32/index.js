// ... rest, ... spread
//                    0          1          2
//                 0  1  2    0  1  2    0  1  2
const numeros = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [9, 8, 7]];
const [lista1, lista2, lista3, ...resto] = numeros;
console.log(lista1[0], lista1[1]);
console.log(lista2[2], lista2[0]);
console.log(lista3[2], lista3[1]);

console.log(resto);


// let a = 'A'
// let b = 'B'
// let c = 'C'
// const ns = [1, 2, 3]
// [a, b, c] = ns
// console.log(a, b, c)
// const noms = [1, 2, 3]
// [a, b, c] = noms
// console.log(a, b, c)