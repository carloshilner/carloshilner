const pessoa = {
  nome: 'Luiz',
  sobrenome: 'Miranda',
  idade: 30,
  endereco: {
    rua: 'Av Brasil',
    numero: 320
  }
};

// Atribuição via desestruturação
const { nome, sobrenome, ...resto } = pessoa;
// const { nome: teste = 'wqe'} = pessoa;
console.log(nome, resto);
console.log(nome, sobrenome);

const { endereco: { rua, numero } } = pessoa;
console.log(rua, numero);