// Escreva uma função que recebe 2 números e 
// retorne o maior deles
const max2 = (x, y) => x > y ? x : y;
console.log(max2(10, 5));
