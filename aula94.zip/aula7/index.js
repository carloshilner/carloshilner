// String = Text | Number = Número
const primeiroNumero = 5;
const segundoNumero = 10;
const resultado = primeiroNumero * segundoNumero;
const resultaDuplicado = resultado * 2;
let r3 = resultado * 3
r3 = r3 + 5
console.log(resultaDuplicado);
console.log(r3);
console.log(typeof (resultaDuplicado));