const nome = 'nome teste'
const sobrenome = 'novo'
const idade = 30
const peso = 84
const alturaEmM = 1.80
let imc = peso / alturaEmM * alturaEmM;// peso / altura*altura
let anoNasc = 2025 - idade;//2025 - ano

console.log(nome, sobrenome, 'tem', idade, 'anos')
console.log(`nasceu em ${anoNasc} pesa ${peso}`)
console.log('kg', 'medindo', alturaEmM + 'm', 'de altura','imc dele é',imc)