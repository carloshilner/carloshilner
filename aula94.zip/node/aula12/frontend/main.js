import 'core-js/stable';
import 'regenerator-runtime/runtime';

import './assets/css/style.css';

console.log('Olá mundo 3');
