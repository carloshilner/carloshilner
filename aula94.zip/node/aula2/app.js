const Cachorro = require('./z/mod2');

const c1 = new Cachorro('Dog');
c1.latir();
