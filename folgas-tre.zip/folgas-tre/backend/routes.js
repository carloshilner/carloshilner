const express = require('express');
const router = express.Router();
const db = require('./db');

router.get('/folgas', (req, res) => {
    db.query('SELECT * FROM folgas', (err, results) => {
        if (err) return res.status(500).json({ error: err });
        res.json(results);
    });
});

router.post('/folgas', (req, res) => {
    const { data, motivo, quantidade } = req.body;
    db.query('INSERT INTO folgas (data, motivo, quantidade) VALUES (?, ?, ?)',
        [data, motivo, quantidade],
        (err, results) => {
            if (err) return res.status(500).json({ error: err });

            const novaFolga = { id: results.insertId, data, motivo, quantidade };
            req.io.emit('nova_folga', novaFolga); // <-- envia para todos os clientes conectados
            res.json(novaFolga);
        });
});

router.delete('/folgas/:id', (req, res) => {
    db.query('DELETE FROM folgas WHERE id = ?', [req.params.id], (err) => {
        if (err) return res.status(500).json({ error: err });
        res.json({ success: true });
    });
});

router.put('/folgas/:id', (req, res) => {
    const { data, motivo, quantidade } = req.body;
    const id = req.params.id;

    db.query(
        'UPDATE folgas SET data = ?, motivo = ?, quantidade = ? WHERE id = ?',
        [data, motivo, quantidade, id],
        (err, result) => {
            if (err) {
                console.error('Erro ao atualizar folga:', err); // ADICIONADO LOG
                return res.status(500).json({ error: err });
            }
            res.json({ success: true });
        }
    );
});

router.post('/folgas/consumir/:id', (req, res) => {
    const { quantidade } = req.body;
    const id = req.params.id;
    db.query('UPDATE folgas SET quantidade = quantidade - ? WHERE id = ? AND quantidade >= ?',
        [quantidade, id, quantidade],
        (err, results) => {
            if (err) return res.status(500).json({ error: err });
            if (results.affectedRows === 0) return res.status(400).json({ error: 'Folga insuficiente' });

            db.query('SELECT * FROM folgas WHERE id = ?', [id], (err, rows) => {
                if (err) return res.status(500).json({ error: err });
                req.io.emit('folga_atualizada', rows[0]);  // Emite a folga atualizada
                res.json({ success: true });
            });
        });
});


module.exports = router;