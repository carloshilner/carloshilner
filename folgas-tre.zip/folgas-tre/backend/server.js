const express = require('express');
const cors = require('cors');
const path = require('path');
const http = require('http');
const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server);

const routes = require('./routes');

app.use(cors());
app.use(express.json());

// Injeta o socket no request para que as rotas possam usá-lo
app.use((req, res, next) => {
  req.io = io;
  next();
});

app.use('/api', routes);
app.use(express.static(path.join(__dirname, '../frontend')));

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
