const API_URL = '/api/folgas';

const form = document.getElementById('folgaForm');
const lista = document.getElementById('listaFolgas');

const socket = io();

socket.on('nova_folga', folga => {
    adicionarNaTabela(folga);
});

socket.on('folga_atualizada', folgaAtualizada => {
    const linhas = document.querySelectorAll('#listaFolgas tr');
    linhas.forEach(tr => {
        const data = tr.querySelectorAll('td')[0].innerText;
        const motivo = tr.querySelectorAll('td')[1].innerText;
        if (data === folgaAtualizada.data && motivo === folgaAtualizada.motivo) {
            tr.querySelectorAll('td')[2].innerText = folgaAtualizada.quantidade;
        }
    });
});

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = document.getElementById('data').value;
    const motivo = document.getElementById('motivo').value;
    const quantidade = document.getElementById('quantidade').value;

    const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ data, motivo, quantidade })
    });

    const folga = await res.json();
    form.reset();
});

async function carregarFolgas() {
    const res = await fetch(API_URL);
    const folgas = await res.json();
    const fragment = document.createDocumentFragment();
    folgas.forEach(folga => adicionarNaTabela(folga, fragment));
    lista.appendChild(fragment);
}

function formatarData(dataISO) {
    const [ano, mes, dia] = dataISO.split('T')[0].split('-');
    return `${dia}/${mes}/${ano}`;
}

function adicionarNaTabela(folga, container = lista) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
    <td>${formatarData(folga.data)}</td>
    <td>${folga.motivo}</td>
    <td>${folga.quantidade}</td>
    <td>
      <button class="remover">Remover</button>
      <button class="usar">Usar</button>
      <button class="editar">Editar</button>
    </td>
  `;

    tr.querySelector('.remover').onclick = async () => {
        const res = await fetch(`${API_URL}/${folga.id}`, { method: 'DELETE' });
        if (res.ok) location.reload();
        // carregarFolgas();
    };

    tr.querySelector('.usar').onclick = () => {
        const qtd = prompt('Quantos dias deseja usar?');
        const valor = parseFloat(qtd);
        if (!isNaN(valor) && valor > 0) {
            fetch(`${API_URL}/consumir/${folga.id}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ quantidade: valor })
            }).then(res => {
                if (!res.ok) return alert('Erro ao consumir folga. Verifique a quantidade.');
                folga.quantidade -= valor;
                tr.querySelectorAll('td')[2].innerText = folga.quantidade;
            });
        }
    };    

    tr.querySelector('.editar').onclick = () => {
        const novaData = prompt('Nova data (YYYY-MM-DD):', folga.data);
        const novoMotivo = prompt('Novo motivo:', folga.motivo);
        const novaQtd = prompt('Nova quantidade:', folga.quantidade);

        if (novaData && novoMotivo && novaQtd) {
            fetch(`${API_URL}/${folga.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    data: novaData,
                    motivo: novoMotivo,
                    quantidade: parseFloat(novaQtd)
                })
            }).then(res => {
                if (res.ok) {
                    lista.innerHTML = '';
                    carregarFolgas();
                    // tr.querySelectorAll('td')[0].innerText = formatarData(novaData);
                    // tr.querySelectorAll('td')[1].innerText = novoMotivo;
                    // tr.querySelectorAll('td')[2].innerText = novaQtd;
                    // // Atualiza objeto local para futuras edições/consumo
                    // folga.data = novaData;
                    // folga.motivo = novoMotivo;
                    // folga.quantidade = parseFloat(novaQtd);                      
                } else {
                    alert('Erro ao editar folga');
                }
            });
        }
    };
    container.appendChild(tr);
}

carregarFolgas();